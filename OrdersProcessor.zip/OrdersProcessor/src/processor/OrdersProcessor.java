package processor;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class OrdersProcessor {	
	//this was also changed to package
	ItemData itemsData;
	private boolean multiThreaded;
	private int numberOfOrders;
	private String baseFilename;
	private String resultFilename;
	//this was also private
	Map<Integer, String> idAndSum;
	//i changed this to package so if it doesnt work again try this
	Map<String, Integer> totalItems;


	public OrdersProcessor(ItemData iData, String multi, int numOrd, String
			baseFile, String resultFile) {
		this.itemsData = iData;
		if (multi.equals("y")) {
			multiThreaded = true;
		} else {
			multiThreaded = false;
		}
		this.numberOfOrders = numOrd;
		this.baseFilename = baseFile;
		this.resultFilename = resultFile;
		this.idAndSum = new HashMap<>();
		this.totalItems = new HashMap<>();

	}


	public static void processingSingle(OrdersProcessor op) {
		int numOfFiles = op.numberOfOrders;
		String baseName = op.baseFilename;
		String[] fileNames = new String[numOfFiles];
		String totalSum = "";
		//this allows me to create the strings that represent the file names
		//that need to be processed
		for (int i = 1; i <= numOfFiles; i++) {
			fileNames[i-1] = baseName + i;
		}
		/*
		 * this goes through each file and creates a summary for it and adds it
		 * to the op's idAndSum. It also keeps track of all of the totalItems
		 * throughout the files that are being passed in.
		 */
		for (String s: fileNames) {
			processSummary(s, op);
		}
		/*
		 * so now i just need to write the summaries in sorted order (by id num)
		 * and then generate a summary for the total number of items, the total
		 * summary can be done by an aux method.
		 */
		//this has gotten me a sorted list of keys for the idAndSum map.
		List<Integer> sortedIds = new ArrayList<Integer>(op.idAndSum.keySet());
		Collections.sort(sortedIds);
		List<Integer> idKeys = new ArrayList<>(sortedIds);

		//now i want to sort the totalItems list of keys

		List<String> sortedItems = new ArrayList<String>(
				op.totalItems.keySet());
		Collections.sort(sortedItems);
		List<String> itemsKeys = new ArrayList<>(sortedItems);
		/*
		 * so now i have the sorted id numbers and the sorted items keys.
		 * Now i just need to write the String associated with the id Number to
		 * the desitnation file, and then generate a summary of the total items
		 * using the aux method, probably should pass in the map of total items
		 */
		try {
			FileWriter writer = new FileWriter(op.resultFilename);
			//System.out.print(op.resultFilename);
			//so this writes all of the individual summaries to the file
			for (Integer i: idKeys) {
				writer.write(op.idAndSum.get(i));
			}
			//this is going to write the overall summary to the file
			totalSum = sumGen(op, itemsKeys);
			writer.write(totalSum);


			writer.close();
			writer.flush();
		} catch (IOException e) {
			System.err.print(e.getMessage());
		}
	}

	private static String sumGen(OrdersProcessor op, List<String> itemKeys) {
		NumberFormat df = NumberFormat.getCurrencyInstance();
		String result = ""; 
		Double total = 0.00;
		result += "***** Summary of all orders *****\n";
		for (String s: itemKeys) {
			result += "Summary - Item's name: " + s + ", Cost per item: " +
					df.format(op.itemsData.getItemPrice(s)) + ", Number sold: " 
					+ op.totalItems.get(s) + ", Item's Total: " + 
					df.format(op.totalItems.get(s) *
							op.itemsData.getItemPrice(s)) + "\n";

			total += op.totalItems.get(s) * op.itemsData.getItemPrice(s);
		}

		result += "Summary Grand Total: " + df.format(total);





		return result;

	}
	private static void processSummary(String fileName, OrdersProcessor op) {
		String result = "";
		String idString = "";
		int id = 0;
		try {
			BufferedReader br = new BufferedReader(new FileReader(fileName +
					".txt"));

			//this will get me the first line
			String line = br.readLine();
			//this assigns the number to the second box of the arrya
			String[] parts = line.split(":");
			//this turns the string version of the id number into the int versio
			id = Integer.parseInt(parts[1].trim());

			/*
			 * now i am going to create a person and I am going to add the items
			 * to that persons map of items. 
			 */

			Person p = new Person(id);
			/*
			 * now i am going to go through the rest of the file, i am going to 
			 * get the item from the line, and then i will have an if statement 
			 * that checks if the person p's map already contains that item and 
			 * if it does, then it is going to replace the value by incrementing
			 * it by one and if its not there then it will just add the item to 
			 * the map with a vlaue of one
			 * 
			 * first i need to get the item from line
			 * 
			 * this while loop allows me to get the next line, and then split 
			 * the line based off of the space between the item and the date
			 * 
			 * then it checks if the persons items map already has that item and
			 * if it does then it replaces the value by incrementing it by one 
			 * and if the map doesnt contain the item, then it adds the item 
			 * with a count of 1
			 * 
			 * Going back through i also want to add it to the map of total
			 * items. so before i check if the person has the items, i will
			 * go through and add them to the total number of items just like
			 * how i did with the person.
			 */
			while ((line = br.readLine()) != null) {
				parts = line.split(" ");
				//handles total items
				if (op.totalItems.containsKey(parts[0])) {
					int num = op.totalItems.get(parts[0]);
					op.totalItems.put(parts[0], num + 1);
				} else {
					op.totalItems.put(parts[0], 1);
				}

				//handles individual people
				if (p.items.containsKey(parts[0])) {
					int num = p.items.get(parts[0]);
					p.items.put(parts[0], num + 1);
				} else {
					p.items.put(parts[0], 1);
				}
			}
			/*
			 * now i need to generate the string that represents the summary, 
			 * so now i need to print the id with the right string and then i 
			 * have to go through and alphabetically add the 
			 * 
			 * this line represents the first line of the summary which adds the 
			 * id to the result
			 */
			result += "----- Order details for client with Id: " + p.id + 
					" -----\n";
			/*
			 * now i should create an array of the keys and sort them 
			 * alphabetically that way when i create the summary while getting 
			 * the numbers, it will add them to the result in the right order.
			 */
			//this gets all of the keys from the map and sorts them
			List<String> sortedKeys = new ArrayList<>(p.items.keySet());
			Collections.sort(sortedKeys);
			List<String> keys = new ArrayList<>(sortedKeys);
			/*
			 * now i need to go through the arrayList and get all of the info
			 * that is associated with the item in the array list
			 * 
			 * this loops through the keys and gets the item name, then the cost
			 * per item, then the quantity, then the total cost
			 */
			double orderSum = 0.00;
			NumberFormat df = NumberFormat.getCurrencyInstance();
			for (String s: keys) {
				result += "Item's name: " + s + ", Cost per item: " + 
						df.format(op.itemsData.getItemPrice(s)) + ", Quantity: "
						+ p.items.get(s) + ", Cost: " + 
						df.format(op.itemsData.getItemPrice(s) * p.items.get(s))
						+ "\n";

				orderSum += op.itemsData.getItemPrice(s) * p.items.get(s);

			}
			result += "Order Total: " + df.format(orderSum) + "\n";
			op.idAndSum.put(id, result);

			/*
			 * so at this point, op has a summary for each file and each item in
			 * the summary is sorted in alphabetical order. these summaries are 
			 * in a map in the order processor but they are not in sorted order.
			 * So now i need to sort the summaries by their id number and then i
			 * will write them to the file. Then i need to create a method that 
			 * will sort the keys and int in the total items map and then create
			 * a total summary. then it will write the summary to the 
			 * destination file. I should also synchronize the total items map 
			 * and the idAndSum map in some way because that is the only 
			 * variable controlled by multiple threads in the future.
			 */


		} catch (IOException e) {
			System.err.print(e.getMessage());
		}
	}


	public static void processingMulti(OrdersProcessor op) {
		String totalSum = "";
		/*
		 * in this method, i want to create a thread array.
		 * each thread is given op, and a file name. first i create an array of
		 * the file names that are needed. Now i need to create an array of
		 * threads, and as i create each thread, i pass in op as well as the 
		 * corresponding fileName. 
		 */
		//this chucnk of code, allows me to create an array of the file names
		//needed
		int numOfFiles = op.numberOfOrders;
		String baseName = op.baseFilename;
		String[] fileNames = new String[numOfFiles];
		for (int i = 1; i <= numOfFiles; i++) {
			fileNames[i-1] = baseName + i;
		}
		/*
		 * here is where i am going to create the threads. I start with an array
		 * of the threads, and then i iterate through the array assigning each
		 * index to a new thread with the op and the file name that it needs to
		 * process.
		 */
		Thread[] threads = new Thread[numOfFiles];
		for (int i = 0; i < numOfFiles; i++) {
			OrderThread ot = new OrderThread(op, fileNames[i]);
			threads[i] = new Thread(ot);
		}

		for (Thread thread: threads) {
			thread.start();
		}

		for (Thread thread: threads) {
			try {
				thread.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.err.print("\n" + e.getMessage());
			}
		}

		/*
		 * this is now the part, where they assign the id and summaries to the
		 * op so after this is where i would generate the total sum
		 */

		List<Integer> sortedIds = new ArrayList<Integer>(op.idAndSum.keySet());
		Collections.sort(sortedIds);
		List<Integer> idKeys = new ArrayList<>(sortedIds);

		//now i want to sort the totalItems list of keys

		List<String> sortedItems = new ArrayList<String>(
				op.totalItems.keySet());
		Collections.sort(sortedItems);
		List<String> itemsKeys = new ArrayList<>(sortedItems);
		/*
		 * so now i have the sorted id numbers and the sorted items keys.
		 * Now i just need to write the String associated with the id Number to
		 * the desitnation file, and then generate a summary of the total items
		 * using the aux method, probably should pass in the map of total items
		 */
		try {
			FileWriter writer = new FileWriter(op.resultFilename);
			//System.out.print(op.resultFilename);
			//so this writes all of the individual summaries to the file
			for (Integer i: idKeys) {
				String test = op.idAndSum.get(i);
				writer.write(op.idAndSum.get(i));
			}
			//this is going to write the overall summary to the file
			totalSum = sumGen(op, itemsKeys);
			writer.write(totalSum);


			writer.close();
			writer.flush();
		} catch (IOException e) {
			System.err.print(e.getMessage());
		}
	}
	public static void main(String[] args) throws 
	FileNotFoundException, IOException {
		Scanner scanner = new Scanner(System.in);

		//data file
		System.out.print("Enter item's data file name: ");
		String itemsDataFileName = scanner.nextLine();
		ItemData itemData = new ItemData(itemsDataFileName);
		//handles multithreading
		System.out.print("Enter 'y' for multiple threads, any "
				+ "other character otherwise: ");
		String multiBool = scanner.nextLine();
		//orders to process
		System.out.print("Enter number of orders to process: ");
		String numberOfOrdersString = scanner.nextLine();
		int numberOfOrders = Integer.parseInt(numberOfOrdersString);
		//base file name
		System.out.print("Enter order's base filename: ");
		String baseFilename = scanner.nextLine();
		//resultFile name
		System.out.print("Enter result's filename: ");
		String resultFilename = scanner.nextLine();


		OrdersProcessor op = new OrdersProcessor(itemData, multiBool,
				numberOfOrders, baseFilename, resultFilename);

		if (op.multiThreaded == false) {
			long startTime = System.currentTimeMillis();
			processingSingle(op);
			long endTime = System.currentTimeMillis();
			System.out.println("Processing time (msec): " + 
			(endTime - startTime));
		} else {
			long startTime = System.currentTimeMillis();
			processingMulti(op);
			long endTime = System.currentTimeMillis();
			System.out.println("Processing time (msec): " + 
			(endTime - startTime));
		}

	}
	//i <3 elias

}