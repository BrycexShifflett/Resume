package processor;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ItemData {
	private static final Map<String, Double> items = new HashMap<>();

	//this is the constructor
	public ItemData(String itemsDataFileName) throws
	FileNotFoundException, IOException {
		readItemsData(itemsDataFileName);
	}
	/*
	 * this method allows us to get the name and prices of items in the file 
	 * that is provided to us by the user. first it creates the reader that we
	 * need to access the file, then we create a string variable that represents
	 * the current line we are on in the file. after that we create an array
	 * of string, the first index will store the name of the item and the second
	 * index will store a string version of the price
	 * after we assign the item name as the first index, we get the price in
	 * double form by calling the parseDouble method and passing in the string
	 * version of the double from the file.
	 * after we have gotten the name and price, we add them to the map of items
	 */
	private void readItemsData(String itemsDataFileName) throws 
	FileNotFoundException, IOException {
		try (BufferedReader reader = new BufferedReader(new 
				FileReader(itemsDataFileName))) {
			String line;
			while ((line = reader.readLine()) != null) {
				String[] parts = line.split(" ");
				if (parts.length == 2) {
					String itemName = parts[0].trim();
					double itemPrice = Double.parseDouble(parts[1].trim());
					items.put(itemName, itemPrice);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/*
	 * this method could help with minimizing code duplication or redundancy,
	 * havent tested or used it yet just thought it might help
	 * 
	 * edit: it does work and does its job great
	 */
	public double getItemPrice(String itemName) {
		Double price = items.get(itemName);
		if (price != null) {
			return price;
		} else {
			throw new IllegalArgumentException("Item not found: " + itemName);
		}
	}
	//this returns the map of items
	public Map<String, Double> getItems() {
		return items;
	}
}
