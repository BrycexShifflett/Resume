package processor;

import java.util.HashMap;
import java.util.Map;
/*
 * this class is mostly just so i can store a persons items which is represented
 * by a map of strings and integers
 */
public class Person {
	int id;
	Map<String, Integer> items;




	public Person(int id) {
		this.id = id;
		this.items = new HashMap<>();
	}


}



