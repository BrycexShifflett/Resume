package processor;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class OrderThread implements Runnable{

	private OrdersProcessor op;
	private String fileName;

	/*
	 * here i am passing in the orderprocessor that i want to modify with the
	 */
	public OrderThread(OrdersProcessor op, String fileName) {
		this.op = op;
		this.fileName = fileName;
	}


	@Override
	public void run() {
		String result = "";
		String idString = "";
		int id = 0;
		try {
			BufferedReader br = new BufferedReader(new FileReader(fileName +
					".txt"));

			//this will get me the first line
			String line = br.readLine();
			//this assigns the number to the second box of the arrya
			String[] parts = line.split(":");
			//this turns the string version of the id number into the int versio
			id = Integer.parseInt(parts[1].trim());

			/*
			 * now i am going to create a person and I am going to add the items
			 * to that persons map of items. 
			 */

			Person p = new Person(id);


			//we synch these two maps because theyre the only thing accessed by
			//threads
			synchronized(this.op.idAndSum) {
				synchronized(this.op.totalItems) {

					while ((line = br.readLine()) != null) {
						parts = line.split(" ");
						//handles total items
						if (op.totalItems.containsKey(parts[0])) {
							int num = op.totalItems.get(parts[0]);
							op.totalItems.put(parts[0], num + 1);
						} else {
							op.totalItems.put(parts[0], 1);
						}

						//handles individual people
						if (p.items.containsKey(parts[0])) {
							int num = p.items.get(parts[0]);
							p.items.put(parts[0], num + 1);
						} else {
							p.items.put(parts[0], 1);
						}
					}
					/*
					 * now i need to generate the string that represents the 
					 * summary 
					 * so now i need to print the id with the right string and 
					 * then  
					 * have to go through and alphabetically add the 
					 * 
					 * this line represents the first line of the summary which 
					 * adds
					 * id to the result
					 */
					result += "----- Order details for client with Id: " + p.id 
							+ " -----\n";
					/*
					 * now i should create an array of the keys and sort them 
					 * alphabetically that way when i create the summary while 
					 * getti 
					 * the numbers, it will add them to the result in the right
					 *  orde
					 */
					//this gets all of the keys from the map and sorts them
					List<String> sortedKeys = new ArrayList<>(p.items.keySet());
					Collections.sort(sortedKeys);
					List<String> keys = new ArrayList<>(sortedKeys);
					/*
					 * now i need to go through the arrayList and get all of the
					 *  inf
					 * that is associated with the item in the array list
					 * 
					 * this loops through the keys and gets the item name, then 
					 * the 
					 * per item, then the quantity, then the total cost
					 */
					double orderSum = 0.00;
					NumberFormat df = NumberFormat.getCurrencyInstance();
					for (String s: keys) {
						result += "Item's name: " + s + ", Cost per item: " + 
								df.format(op.itemsData.getItemPrice(s)) +
								", Quantity: "+ p.items.get(s) + ", Cost: " + 
								df.format(op.itemsData.getItemPrice(s) *
										p.items.get(s))+ "\n";

						orderSum += op.itemsData.getItemPrice(s) * 
								p.items.get(s);

					}
					result += "Order Total: " + df.format(orderSum) + "\n";
					op.idAndSum.put(id, result);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}






}
